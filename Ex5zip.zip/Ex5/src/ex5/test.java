package ex5;

public class test {
	
	    public static void main(String[] args) {
	        Compte compte = new Compte("Alice", 500.0);

	        try {
	            compte.verser(-100.0); 
	        } catch (MontantNegatifException e) {
	            System.out.println(e.getMessage()); 
	        }

	        try {
	            compte.retirer(-50.0); 
	        } catch (MontantNegatifException e) {
	            System.out.println(e.getMessage()); 
	        }

	        System.out.println("Solde actuel : " + compte.getSolde());
	    }
	

	
}
