package polymorphisme2;

public class Manager extends Employe {
	public int nombreDeSubordonnes;
	
	 public Manager(String nom, int salaire, int nombreDeSubordonnes) {
	        super(nom, salaire); 
	        this.nombreDeSubordonnes = nombreDeSubordonnes;
	    }

	    @Override
	    public void afficherInfos() {
	        super.afficherInfos(); 
	        System.out.println("Nombre de subordonnés : " + nombreDeSubordonnes);
	    }

	    public void gererEquipe() {
	        System.out.println("Le manager " + getNom() + " gère une équipe de " + nombreDeSubordonnes + " subordonnés.");
	    }

}
