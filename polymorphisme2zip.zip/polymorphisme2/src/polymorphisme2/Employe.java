package polymorphisme2;

public class Employe {
	public String nom;
	public int salaire;
	
public Employe(String nom, int salaire) {
        this.nom = nom;
        this.salaire = salaire;
}

public void afficherInfos() {
    System.out.println("Nom de l'employé : " + nom);
    System.out.println("Salaire : " + salaire + " DH");
}
        
public String getNom() {
    return nom;
}

public int getSalaire() {
    return salaire;
}
     

}
