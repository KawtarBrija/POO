package polymorphisme2;

public class upcasting {
//Le sur-casting (ou upcasting) est un concept de la programmation orientée objet
	//qui permet d'assigner un objet d'une sous-classe à une référence de la classe parente.
	//En Java, le sur-casting est généralement sans risque et se produit automatiquement
	//lorsque vous assignez un objet d'une sous-classe à une variable de type classe parente.
	
	    public static void main(String[] args) {
	      
	        Developpeur dev = new Developpeur("arij hachim", 4000, "Java");
	       
	        Employe employe = dev;

	        employe.afficherInfos();
	    }
	}


