package polymorphisme2;

public class downcasting {
	//Le sous-casting (ou downcasting) est un processus qui permet de convertir une référence
	//d'un type de classe parente en une référence d'une sous-classe. Ce processus nécessite
	//souvent une vérification du type réel de l'objet à l'aide de l'opérateur instanceof pour
	//éviter les exceptions ClassCastException.

	    public static void main(String[] args) {
	      
	        Employe employe = new Manager("ikram ghazzali", 5000, 10);
	        
	       
	        if (employe instanceof Manager) {
	            Manager manager = (Manager) employe;
	            manager.gererEquipe();
	        }

	        employe = new Developpeur("hiba talha", 4000, "Java");
	        
	        if (employe instanceof Developpeur) {
	            Developpeur developpeur = (Developpeur) employe;
	            developpeur.afficherLangage();
	        }
	    }
	

}
