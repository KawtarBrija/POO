package polymorphisme2;

public class test {
	
	  public static void main(String[] args) {
	  
	        Employe[] employes = new Employe[3];

	        employes[0] = new Developpeur("kawtar brija", 4000, "Java");
	        employes[1] = new Manager("marwa ghazzali", 5000, 10);
	        employes[2] = new Developpeur("aya nouza", 4500, "Python");
	        
	        for (Employe employe : employes) {
	            employe.afficherInfos();
	            System.out.println(); 
	        }
	    }
}


