package gestionDeCompteExceptions;

public class Compte {
	
	    private String titulaire;
	    private double solde;

	    public Compte(String titulaire, double soldeInitial) {
	        this.titulaire = titulaire;
	        this.solde = soldeInitial;
	    }

	    public void deposer(double montant) {
	        if (montant > 0) {
	            solde += montant;
	            System.out.println("Montant déposé : " + montant);
	        } else {
	            System.out.println("Le montant à déposer doit être positif !");
	        }
	    }

	    public void retirer(double montant) throws SoldeInsuffisantException {
	        if (montant > solde) {
	            throw new SoldeInsuffisantException("Erreur : Solde insuffisant !");
	        } else {
	            solde -= montant;
	            System.out.println("Montant retiré : " + montant);
	        }
	    }

	    public double getSolde() {
	        return solde;
	    }

	

}
