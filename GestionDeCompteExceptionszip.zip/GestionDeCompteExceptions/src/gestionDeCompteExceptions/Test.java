package gestionDeCompteExceptions;

public class Test {
	
	    public static void main(String[] args) {
	        Compte compte = new Compte("Alice", 500.0);
	        
	        try {
	            compte.retirer(600.0); 
	        } catch (SoldeInsuffisantException e) {
	            System.out.println(e.getMessage());
	        }
	        
	        System.out.println("Solde actuel : " + compte.getSolde());
	    }


}
