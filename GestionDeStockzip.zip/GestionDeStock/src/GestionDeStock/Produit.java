package GestionDeStock;

public interface Produit {
	 double calculerValeurStock();
}
