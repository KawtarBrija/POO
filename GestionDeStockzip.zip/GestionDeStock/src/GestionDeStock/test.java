package GestionDeStock;

public class test {
	 public static void main(String[] args) {
	        Produit produitAlimentaire = new ProduitAlimentaire(2.5, 100);
	        System.out.println("Valeur du stock de produit alimentaire : " + produitAlimentaire.calculerValeurStock() + " DH");

	        Produit produitElectronique = new ProduitElectronique(500, 20);
	        System.out.println("Valeur du stock de produit électronique : " + produitElectronique.calculerValeurStock() + " DH");
	    }

}
