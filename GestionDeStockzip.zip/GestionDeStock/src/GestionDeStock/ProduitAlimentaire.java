package GestionDeStock;

public class ProduitAlimentaire implements Produit {
	private double prixUnitaire;
	private int quantiteEnStock;
	
	public ProduitAlimentaire (double prixUnitaire, int quantiteEnStock) {
		this.prixUnitaire = prixUnitaire;
		this.quantiteEnStock = quantiteEnStock;
	}
	@Override
	public double calculerValeurStock() {
		return prixUnitaire * quantiteEnStock;
	}

}
