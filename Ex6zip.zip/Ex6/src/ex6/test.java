package ex6;
import java.util.InputMismatchException;
import java.util.Scanner;

public class test {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Compte compte = new Compte("Alice", 500.0);
        
        while (true) {
            System.out.print("Entrez un montant à retirer : ");
            try {
                double montant = scanner.nextDouble();
                compte.retirer(montant);
            } catch (MontantNegatifException e) {
                System.out.println(e.getMessage()); 
            } catch (SoldeInsuffisantException e) {
                System.out.println(e.getMessage()); 
            } catch (InputMismatchException e) {
                System.out.println("Erreur : Vous devez entrer un nombre valide."); 
                scanner.next(); 
            }

            System.out.println("Solde actuel : " + compte.getSolde());
            
            System.out.print("Voulez-vous continuer ? (oui/non) : ");
            String reponse = scanner.next();
            if (!reponse.equalsIgnoreCase("oui")) {
                break;
            }
        }
        scanner.close();
    }

}
