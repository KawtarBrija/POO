/**
 * 
 */
/**
 * 
 */
module Ex6 {
}