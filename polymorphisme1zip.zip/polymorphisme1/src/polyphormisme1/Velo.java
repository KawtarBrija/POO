package polyphormisme1;

public class Velo extends Vehicule {
	   
	    public Velo(String marque, String modele) {
	        super(marque, modele);
	    }

	    @Override
	    public void seDeplacer() {
	        System.out.println("Le vélo " + marque + " " + modele + " est en mouvement.");
	    }
	}



