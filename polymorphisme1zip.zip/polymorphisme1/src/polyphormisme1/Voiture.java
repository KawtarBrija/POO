package polyphormisme1;

public class Voiture extends Vehicule {

	    public Voiture(String marque, String modele) {
	        super(marque, modele);
	    }
	    
	    @Override
	    public void seDeplacer() {
	        System.out.println("La voiture " + marque + " " + modele + " roule sur la route.");
	    }
	}



