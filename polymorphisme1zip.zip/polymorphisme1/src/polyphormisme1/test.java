package polyphormisme1;

public class test {
	    public static void main(String[] args) {
	        Vehicule voiture = new Voiture("Toyota", "Corolla");
	        Vehicule velo = new Velo("Giant", "Escape 3");

	       
	        voiture.seDeplacer(); 
	        velo.seDeplacer();     
	    }
	}


