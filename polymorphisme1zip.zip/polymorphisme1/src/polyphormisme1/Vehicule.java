package polyphormisme1;

public class Vehicule {
	   public String marque;
	    public String modele;

	    public Vehicule(String marque, String modele) {
	        this.marque = marque;
	        this.modele = modele;
	    }

	    public void seDeplacer() {
	        System.out.println("Le véhicule " + marque + " " + modele + " est en déplacement.");
	    }
}
