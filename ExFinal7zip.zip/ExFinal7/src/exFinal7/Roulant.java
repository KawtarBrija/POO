package exFinal7;

public interface Roulant {
void rouler();
}
