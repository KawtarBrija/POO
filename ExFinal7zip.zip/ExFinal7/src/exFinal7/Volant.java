package exFinal7;

public interface Volant {
	void voler();

}
