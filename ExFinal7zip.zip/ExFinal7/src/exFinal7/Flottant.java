package exFinal7;

public interface Flottant {
	 void flotter();

}
