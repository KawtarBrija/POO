package exFinal7;

public class polymorphisme {
	 public static void main(String[] args) {
	        Vehicule[] vehicules = new Vehicule[3];

	        vehicules[0] = new Voiture("Toyota", "Essence");
	        vehicules[1] = new Bateau("Titanic", "Diesel");
	        vehicules[2] = new Hydravion("HydroJet", "Kérosène");

	        for (Vehicule vehicule : vehicules) {
	            vehicule.afficherInfos(); 
	            vehicule.demarrer(); 
	            
	            if (vehicule instanceof Roulant) {
	                ((Roulant) vehicule).rouler(); // Appel de la méthode rouler() si c'est un Roulant
	            }

	            if (vehicule instanceof Flottant) {
	                ((Flottant) vehicule).flotter(); // Appel de la méthode flotter() si c'est un Flottant
	            }
	            
	            vehicule.arreter();        
	            System.out.println();      
	        }
	    }

}
