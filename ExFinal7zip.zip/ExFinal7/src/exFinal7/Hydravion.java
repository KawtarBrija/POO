package exFinal7;

public class Hydravion extends Vehicule implements Volant,Flottant {
	public Hydravion(String nom, String typeCarburant) {
        super(nom, typeCarburant);
    }

    @Override
    public void demarrer() {
        System.out.println(nom + " démarre avec " + typeCarburant + ".");
    }

    @Override
    public void arreter() {
        System.out.println(nom + " s'arrête.");
    }

    @Override
    public void voler() {
        System.out.println(nom + " est en train de voler.");
    }

    @Override
    public void flotter() {
        System.out.println(nom + " flotte sur l'eau.");
    }

}
