package ex4;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SaisieNombre {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        float nombre = 0.0f; 

	        System.out.print("Entrez un nombre : ");

	        try {
	            nombre = scanner.nextFloat(); 
	            System.out.println("Vous avez entré : " + nombre);
	        } catch (InputMismatchException e) {
	            System.out.println("Erreur : Vous devez entrer un nombre valide.");
	        } finally {
	            
	            scanner.close();
	        }
	    }
	
}
