package FormesGeometrique;

public abstract class Forme {
	
	 public abstract double calculerSurface();

	 public abstract double calculerPerimetre();

}
